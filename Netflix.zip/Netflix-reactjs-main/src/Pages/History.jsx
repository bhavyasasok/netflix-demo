import React from "react";
import UserMovieSection from "../componets/UserMovieSection/UserMovieSection";

function History() {
  return <UserMovieSection from="WatchedMovies"></UserMovieSection>;
}

export default History;
